import os
import time
import json
import requests
import subprocess
from dotenv import load_dotenv
from requests_toolbelt.multipart.encoder import MultipartEncoder

# Load environment variables
load_dotenv()

# === CONFIGURATION ===
TIKTOK_USERNAME = os.getenv("TIKTOK_USERNAME")
LAST_VIDEO_FILE = "last_video_url.txt"
BLUESKY_IDENTIFIER = os.getenv("BLUESKY_IDENTIFIER")
BLUESKY_PASSWORD = os.getenv("BLUESKY_PASSWORD")
BLUESKY_API = "https://bsky.social/xrpc/com.atproto.repo.createRecord"
BLUESKY_UPLOAD_API = "https://bsky.social/xrpc/com.atproto.repo.uploadBlob"

# === FUNCTIONS ===
def get_latest_tiktok_url():
    rss_url = f"https://rsshub.app/tiktok/user/{TIKTOK_USERNAME}"
    res = requests.get(rss_url)
    if res.status_code != 200:
        raise Exception("Failed to fetch TikTok RSS feed.")
    # crude way to find first TikTok link in XML
    start = res.text.find("<link>https://www.tiktok.com/")
    end = res.text.find("</link>", start)
    if start != -1 and end != -1:
        return res.text[start+6:end]
    return None

def load_last_video_url():
    if os.path.exists(LAST_VIDEO_FILE):
        with open(LAST_VIDEO_FILE, "r") as f:
            return f.read().strip()
    return None

def save_last_video_url(url):
    with open(LAST_VIDEO_FILE, "w") as f:
        f.write(url)

def download_video(video_url):
    filename = "latest_tiktok.mp4"
    command = ["yt-dlp", "-f", "mp4", "-o", filename, video_url]
    result = subprocess.run(command, capture_output=True)
    if result.returncode != 0:
        raise Exception("Video download failed: " + result.stderr.decode())
    return filename

def login_to_bluesky():
    res = requests.post(
        "https://bsky.social/xrpc/com.atproto.server.createSession",
        json={"identifier": BLUESKY_IDENTIFIER, "password": BLUESKY_PASSWORD}
    )
    res.raise_for_status()
    return res.json()["accessJwt"]

def upload_video_to_bluesky(jwt_token, video_bytes, mime_type="video/mp4"):
    headers = {"Authorization": f"Bearer {jwt_token}"}
    m = MultipartEncoder(fields={"file": ("video.mp4", video_bytes, mime_type)})
    headers["Content-Type"] = m.content_type
    res = requests.post(BLUESKY_UPLOAD_API, headers=headers, data=m)
    res.raise_for_status()
    return res.json()["blob"]

def post_to_bluesky(jwt_token, blob_ref, video_url):
    headers = {"Authorization": f"Bearer {jwt_token}"}
    record = {
        "repo": BLUESKY_IDENTIFIER,
        "collection": "app.bsky.feed.post",
        "record": {
            "$type": "app.bsky.feed.post",
            "text": f"New TikTok posted!\n{video_url}",
            "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "embed": {
                "$type": "app.bsky.embed.media",
                "media": blob_ref,
                "alt": "TikTok video"
            }
        }
    }
    res = requests.post(BLUESKY_API, headers=headers, json=record)
    res.raise_for_status()
    return res.json()

# === MAIN LOGIC ===
def main():
    try:
        last_url = load_last_video_url()
        latest_url = get_latest_tiktok_url()

        if not latest_url or latest_url == last_url:
            print("No new videos found.")
            return

        print(f"New TikTok found: {latest_url}")
        filename = download_video(latest_url)

        jwt = login_to_bluesky()
        with open(filename, "rb") as f:
            blob = upload_video_to_bluesky(jwt, f.read())
        post_to_bluesky(jwt, blob, latest_url)
        print("Posted to Bluesky!")
        save_last_video_url(latest_url)
    finally:
        if os.path.exists("latest_tiktok.mp4"):
            os.remove("latest_tiktok.mp4")
            print("Deleted local video file.")

if __name__ == "__main__":
    main()
